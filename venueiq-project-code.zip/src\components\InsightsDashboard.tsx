import { TrendingUp, AlertTriangle, Zap, Target, Users, Activity, LineChart } from 'lucide-react';
import type { CrowdAnomaly, CrowdPrediction, ZoneHistory, FacilityPerformance, Zone } from '../types';
import { predictNextSurge, generateTrendArrow } from '../lib/analytics';

interface InsightsDashboardProps {
  anomalies: CrowdAnomaly[];
  predictions: CrowdPrediction[];
  zoneHistory: ZoneHistory[];
  zones: Zone[];
  facilityPerformance: FacilityPerformance[];
}

function PerformanceCard({
  title, value, metric, trend, color, icon,
}: {
  title: string; value: string; metric: string; trend?: string; color: string; icon: React.ReactNode;
}) {
  return (
    <div className="bg-white rounded-xl border border-slate-100 p-4">
      <div className="flex items-start justify-between mb-2">
        <span className={`p-2 rounded-lg ${color}`}>{icon}</span>
        {trend && <span className="text-xs font-bold text-slate-500">{trend}</span>}
      </div>
      <p className="text-2xl font-bold text-slate-900">{value}</p>
      <p className="text-xs text-slate-500 mt-1">{metric}</p>
      <p className="text-xs text-slate-400 mt-2">{title}</p>
    </div>
  );
}

export function InsightsDashboard({
  anomalies, predictions, zoneHistory, zones, facilityPerformance,
}: InsightsDashboardProps) {
  const surgePredictions = predictNextSurge(zoneHistory);
  const criticalAnomalies = anomalies.filter((a) => a.severity === 'critical' && !a.resolved);
  const severAnomalies = anomalies.filter((a) => a.severity === 'severe' && !a.resolved);

  const avgEfficiency = facilityPerformance.length > 0
    ? Math.round(facilityPerformance.reduce((s, f) => s + f.efficiency_score, 0) / facilityPerformance.length)
    : 0;

  const staffUtilization = facilityPerformance.length > 0
    ? Math.round(facilityPerformance.reduce((s, f) => s + f.staff_utilization, 0) / facilityPerformance.length)
    : 0;

  const bestPrediction = predictions
    .filter((p) => p.time_horizon === '15min')
    .sort((a, b) => b.confidence_score - a.confidence_score)[0];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <PerformanceCard
          title="System Efficiency"
          value={`${avgEfficiency}%`}
          metric="All facilities"
          color="bg-blue-100"
          icon={<Activity size={18} className="text-blue-600" />}
          trend={avgEfficiency > 75 ? '↑ Strong' : avgEfficiency > 50 ? '→ Stable' : '↓ Needs Help'}
        />
        <PerformanceCard
          title="Staff Utilization"
          value={`${staffUtilization}%`}
          metric="Workload balance"
          color="bg-emerald-100"
          icon={<Users size={18} className="text-emerald-600" />}
          trend={staffUtilization > 80 ? 'Critical' : staffUtilization > 60 ? 'High' : 'Manageable'}
        />
        <PerformanceCard
          title="Crowd Anomalies"
          value={String(criticalAnomalies.length + severAnomalies.length)}
          metric={`${criticalAnomalies.length} critical`}
          color="bg-red-100"
          icon={<AlertTriangle size={18} className="text-red-600" />}
        />
        <PerformanceCard
          title="ML Confidence"
          value={bestPrediction ? `${Math.round(bestPrediction.confidence_score)}%` : 'N/A'}
          metric="Next 15 minutes"
          color="bg-purple-100"
          icon={<Zap size={18} className="text-purple-600" />}
        />
      </div>

      {criticalAnomalies.length > 0 && (
        <div className="bg-gradient-to-r from-red-50 to-orange-50 rounded-2xl border border-red-200 p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle size={20} className="text-red-600 mt-0.5 shrink-0" />
            <div className="flex-1">
              <p className="font-bold text-red-900">Critical Anomalies Detected</p>
              <div className="space-y-2 mt-3">
                {criticalAnomalies.slice(0, 3).map((anom) => {
                  const zone = zones.find((z) => z.id === anom.zone_id);
                  return (
                    <div key={anom.id} className="flex items-start gap-2 bg-white/60 rounded-lg p-2">
                      <span className="text-xs font-bold text-red-600 uppercase shrink-0 mt-0.5">
                        {anom.anomaly_type.replace('_', ' ')}
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-800">{zone?.name || 'Unknown Zone'}</p>
                        <p className="text-xs text-slate-600 line-clamp-1">{anom.description}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl border border-slate-100 p-4">
          <div className="flex items-center gap-2 mb-4">
            <LineChart size={18} className="text-slate-600" />
            <h3 className="font-bold text-slate-800">Crowd Surge Predictions</h3>
          </div>
          <div className="space-y-3">
            {surgePredictions.length > 0 ? (
              surgePredictions.slice(0, 4).map((pred) => {
                const zone = zones.find((z) => z.id === pred.zoneId);
                const riskColor = pred.riskScore > 80 ? 'text-red-600' : pred.riskScore > 60 ? 'text-orange-600' : 'text-amber-600';
                return (
                  <div key={pred.zoneId} className="flex items-center justify-between p-2 bg-slate-50 rounded-lg">
                    <div>
                      <p className="text-sm font-semibold text-slate-800">{zone?.name}</p>
                      <p className="text-xs text-slate-500">{pred.timeToSurge}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-lg font-bold ${riskColor}`}>{Math.round(pred.riskScore)}%</p>
                      <p className="text-xs text-slate-400">Risk Score</p>
                    </div>
                  </div>
                );
              })
            ) : (
              <p className="text-sm text-slate-500 py-8 text-center">No surge predictions at this time</p>
            )}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-100 p-4">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp size={18} className="text-slate-600" />
            <h3 className="font-bold text-slate-800">Trend Analysis</h3>
          </div>
          <div className="space-y-3">
            {zoneHistory.slice(0, 4).map((hist, idx) => {
              const zone = zones.find((z) => z.id === hist.zone_id);
              const prev = zoneHistory.find((h) => h.zone_id === hist.zone_id && h.id !== hist.id);
              const trend = prev ? generateTrendArrow(hist.occupancy_snapshot, prev.occupancy_snapshot) : 'New';
              return (
                <div key={idx} className="flex items-center justify-between p-2 bg-slate-50 rounded-lg">
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{zone?.name}</p>
                    <p className="text-xs text-slate-500">{trend}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-slate-800">{hist.occupancy_snapshot}</p>
                    <p className="text-xs text-slate-400">Current</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl border border-blue-200 p-4">
        <div className="flex items-start gap-3">
          <Zap size={20} className="text-blue-600 mt-0.5 shrink-0" />
          <div>
            <p className="font-bold text-blue-900">AI Recommendations</p>
            <div className="space-y-2 mt-2 text-sm text-blue-800">
              <p>• Open 2 additional concession registers in North Upper Deck (current wait: 18m)</p>
              <p>• Consider opening East Gate exit to divert West Wing overflow</p>
              <p>• Deploy 1 additional crowd control staff to Zone 66 (surging occupancy)</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 p-4">
        <div className="flex items-center gap-2 mb-4">
          <Target size={18} className="text-slate-600" />
          <h3 className="font-bold text-slate-800">Performance Alerts</h3>
        </div>
        <div className="space-y-2">
          {facilityPerformance.slice(0, 3).map((perf) => {
            const statusColor = perf.efficiency_score > 75 ? 'bg-emerald-100 text-emerald-700' : perf.efficiency_score > 50 ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700';
            return (
              <div key={perf.id} className="flex items-center justify-between p-2 bg-slate-50 rounded-lg">
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-800 truncate">Facility Performance</p>
                  <p className="text-xs text-slate-500">Served: {perf.customers_served} customers</p>
                </div>
                <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${statusColor}`}>
                  {Math.round(perf.efficiency_score)}%
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
