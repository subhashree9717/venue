import { useState } from 'react';
import { User, LogOut, Mail, CreditCard as Edit2, Check, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export function UserProfile() {
  const { user, signOut, updateProfile } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [fullName, setFullName] = useState(user?.user_metadata?.full_name || '');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  if (!user) return null;

  const handleSave = async () => {
    setSaving(true);
    setMessage('');
    const result = await updateProfile({ full_name: fullName });
    if (result.error) {
      setMessage(result.error);
    } else {
      setMessage('Profile updated!');
      setIsEditing(false);
      setTimeout(() => setMessage(''), 2000);
    }
    setSaving(false);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-4">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
          <User size={20} className="text-blue-600" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-slate-800 truncate">{fullName || 'User'}</p>
          <p className="text-xs text-slate-500 truncate flex items-center gap-1">
            <Mail size={12} />
            {user.email}
          </p>
        </div>
        <button
          onClick={() => signOut()}
          className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          title="Sign out"
        >
          <LogOut size={18} className="text-slate-600" />
        </button>
      </div>

      {!isEditing ? (
        <button
          onClick={() => setIsEditing(true)}
          className="w-full flex items-center justify-center gap-2 text-sm font-medium text-blue-600 hover:text-blue-700 py-2"
        >
          <Edit2 size={14} />
          Edit Profile
        </button>
      ) : (
        <div className="space-y-2">
          <input
            type="text"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <div className="flex gap-2">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex-1 flex items-center justify-center gap-1 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium py-2 rounded-lg disabled:opacity-50"
            >
              <Check size={14} />
              Save
            </button>
            <button
              onClick={() => {
                setIsEditing(false);
                setFullName(user.user_metadata?.full_name || '');
              }}
              className="flex-1 flex items-center justify-center gap-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-medium py-2 rounded-lg"
            >
              <X size={14} />
              Cancel
            </button>
          </div>
          {message && (
            <p className={`text-xs ${message.includes('error') ? 'text-red-600' : 'text-emerald-600'}`}>
              {message}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
