import { Wifi, WifiOff, Activity, ChevronDown } from 'lucide-react';
import { useState } from 'react';
import type { Event } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { UserProfile } from './UserProfile';

interface HeaderProps {
  event: Event | null;
  connected: boolean;
}

export function Header({ event, connected }: HeaderProps) {
  const { user } = useAuth();
  const [showProfile, setShowProfile] = useState(false);

  return (
    <header className="bg-slate-900 text-white sticky top-0 z-40 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3 flex-1">
          <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-blue-500">
            <Activity size={20} />
          </div>
          <div>
            <p className="font-bold text-sm leading-tight">VenueIQ</p>
            <p className="text-slate-400 text-xs leading-tight">Smart Crowd Experience</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          {event && (
            <div className="hidden sm:flex items-center gap-2 bg-slate-800 rounded-xl px-3 py-1.5">
              {event.status === 'live' && (
                <span className="flex items-center gap-1.5 text-xs font-bold text-red-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
                  LIVE
                </span>
              )}
              <span className="text-xs text-slate-300 font-medium">
                {event.home_team} {event.home_score} – {event.away_score} {event.away_team}
              </span>
            </div>
          )}

          <div className={`flex items-center gap-1.5 text-xs font-medium px-2.5 py-1.5 rounded-full ${connected ? 'bg-emerald-900/50 text-emerald-400' : 'bg-red-900/50 text-red-400'}`}>
            {connected ? <Wifi size={12} /> : <WifiOff size={12} />}
            {connected ? 'Live' : 'Offline'}
          </div>

          {user && (
            <div className="relative">
              <button
                onClick={() => setShowProfile(!showProfile)}
                className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 rounded-lg px-3 py-1.5 transition-colors text-sm font-medium"
              >
                <span className="truncate max-w-[120px]">{user.user_metadata?.full_name || user.email?.split('@')[0]}</span>
                <ChevronDown size={14} />
              </button>

              {showProfile && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl p-0 z-50">
                  <div className="relative">
                    <button
                      onClick={() => setShowProfile(false)}
                      className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 p-1"
                    >
                      ✕
                    </button>
                    <div className="pt-2 px-4 pb-4">
                      <UserProfile />
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
