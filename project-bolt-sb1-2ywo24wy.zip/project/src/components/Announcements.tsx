import { AlertTriangle, Info, AlertCircle, X, Clock } from 'lucide-react';
import type { Announcement } from '../types';

interface AnnouncementsProps {
  announcements: Announcement[];
  onDismiss: (id: string) => void;
}

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  return `${hrs}h ago`;
}

const PRIORITY_CONFIG = {
  critical: {
    bg: 'bg-red-50 border-red-200',
    iconBg: 'bg-red-100',
    iconColor: 'text-red-600',
    titleColor: 'text-red-900',
    textColor: 'text-red-700',
    badge: 'bg-red-500 text-white',
    label: 'CRITICAL',
    icon: <AlertTriangle size={18} />,
  },
  warning: {
    bg: 'bg-amber-50 border-amber-200',
    iconBg: 'bg-amber-100',
    iconColor: 'text-amber-600',
    titleColor: 'text-amber-900',
    textColor: 'text-amber-700',
    badge: 'bg-amber-500 text-white',
    label: 'WARNING',
    icon: <AlertCircle size={18} />,
  },
  info: {
    bg: 'bg-blue-50 border-blue-200',
    iconBg: 'bg-blue-100',
    iconColor: 'text-blue-600',
    titleColor: 'text-blue-900',
    textColor: 'text-blue-700',
    badge: 'bg-blue-500 text-white',
    label: 'INFO',
    icon: <Info size={18} />,
  },
};

function AnnouncementCard({ announcement, onDismiss }: { announcement: Announcement; onDismiss: () => void }) {
  const cfg = PRIORITY_CONFIG[announcement.priority];

  return (
    <div className={`relative border rounded-2xl p-4 ${cfg.bg} transition-all duration-300`}>
      <div className="flex items-start gap-3">
        <div className={`p-2 rounded-xl shrink-0 ${cfg.iconBg} ${cfg.iconColor}`}>
          {cfg.icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${cfg.badge}`}>
              {cfg.label}
            </span>
            <div className="flex items-center gap-1 text-xs text-slate-400">
              <Clock size={11} />
              {timeAgo(announcement.created_at)}
            </div>
          </div>
          <p className={`font-semibold text-sm leading-tight ${cfg.titleColor}`}>{announcement.title}</p>
          <p className={`text-sm mt-1.5 leading-relaxed ${cfg.textColor}`}>{announcement.message}</p>
        </div>
        <button
          onClick={onDismiss}
          className="shrink-0 text-slate-400 hover:text-slate-600 p-1 -mt-1 -mr-1 transition-colors"
          aria-label="Dismiss"
        >
          <X size={16} />
        </button>
      </div>
    </div>
  );
}

export function Announcements({ announcements, onDismiss }: AnnouncementsProps) {
  const critical = announcements.filter((a) => a.priority === 'critical');
  const warnings = announcements.filter((a) => a.priority === 'warning');
  const info = announcements.filter((a) => a.priority === 'info');

  if (announcements.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-400">
        <Info size={48} className="mb-4 opacity-30" />
        <p className="font-medium">No active announcements</p>
        <p className="text-sm mt-1">All clear at the venue</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-bold text-slate-900">Live Updates</h2>
          <p className="text-sm text-slate-400">{announcements.length} active announcement{announcements.length !== 1 ? 's' : ''}</p>
        </div>
        <div className="flex items-center gap-2">
          {critical.length > 0 && (
            <span className="flex items-center gap-1 text-xs font-bold bg-red-100 text-red-700 px-2.5 py-1 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
              {critical.length} Critical
            </span>
          )}
        </div>
      </div>

      {critical.length > 0 && (
        <div className="space-y-3">
          {critical.map((a) => (
            <AnnouncementCard key={a.id} announcement={a} onDismiss={() => onDismiss(a.id)} />
          ))}
        </div>
      )}

      {warnings.length > 0 && (
        <div className="space-y-3">
          {warnings.map((a) => (
            <AnnouncementCard key={a.id} announcement={a} onDismiss={() => onDismiss(a.id)} />
          ))}
        </div>
      )}

      {info.length > 0 && (
        <div className="space-y-3">
          {info.map((a) => (
            <AnnouncementCard key={a.id} announcement={a} onDismiss={() => onDismiss(a.id)} />
          ))}
        </div>
      )}
    </div>
  );
}
