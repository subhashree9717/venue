import { useState } from 'react';
import { X, Users, AlertTriangle, Clock } from 'lucide-react';
import type { Zone, Facility } from '../types';

interface VenueMapProps {
  zones: Zone[];
  facilities: Facility[];
}

const DENSITY_CONFIG = {
  low: { fill: '#10b981', fillOpacity: 0.15, stroke: '#059669', label: 'Low', text: 'text-emerald-700', badge: 'bg-emerald-100 text-emerald-700' },
  medium: { fill: '#f59e0b', fillOpacity: 0.2, stroke: '#d97706', label: 'Medium', text: 'text-amber-700', badge: 'bg-amber-100 text-amber-700' },
  high: { fill: '#f97316', fillOpacity: 0.3, stroke: '#ea580c', label: 'High', text: 'text-orange-700', badge: 'bg-orange-100 text-orange-700' },
  critical: { fill: '#ef4444', fillOpacity: 0.45, stroke: '#dc2626', label: 'Critical', text: 'text-red-700', badge: 'bg-red-100 text-red-700' },
};

const FACILITY_ICONS: Record<string, string> = {
  concession: '🍔',
  restroom: '🚻',
  first_aid: '🏥',
  gate: '🚪',
  merchandise: '👕',
  exit: '🚪',
};

function ZoneRect({
  zone,
  isSelected,
  onClick,
}: {
  zone: Zone;
  isSelected: boolean;
  onClick: () => void;
}) {
  const config = DENSITY_CONFIG[zone.density_level];
  const pct = Math.round((zone.current_occupancy / zone.capacity) * 100);

  return (
    <g onClick={onClick} className="cursor-pointer" style={{ transition: 'all 0.2s' }}>
      <rect
        x={zone.x_position}
        y={zone.y_position}
        width={zone.width}
        height={zone.height}
        rx={8}
        fill={config.fill}
        fillOpacity={isSelected ? config.fillOpacity * 2 : config.fillOpacity}
        stroke={config.stroke}
        strokeWidth={isSelected ? 2.5 : 1.5}
        strokeDasharray={zone.density_level === 'critical' ? '4 2' : undefined}
      />
      {zone.density_level === 'critical' && (
        <rect
          x={zone.x_position}
          y={zone.y_position}
          width={zone.width}
          height={zone.height}
          rx={8}
          fill={config.fill}
          fillOpacity={0.08}
          stroke="none"
        >
          <animate attributeName="fillOpacity" values="0.08;0.2;0.08" dur="1.5s" repeatCount="indefinite" />
        </rect>
      )}
      <text
        x={zone.x_position + zone.width / 2}
        y={zone.y_position + zone.height / 2 - 6}
        textAnchor="middle"
        dominantBaseline="middle"
        fontSize={Math.min(11, zone.width / 8)}
        fontWeight="600"
        fill={config.stroke}
      >
        {zone.section_code}
      </text>
      <text
        x={zone.x_position + zone.width / 2}
        y={zone.y_position + zone.height / 2 + 8}
        textAnchor="middle"
        dominantBaseline="middle"
        fontSize={Math.min(9, zone.width / 10)}
        fill={config.stroke}
        fontWeight="500"
      >
        {pct}%
      </text>
    </g>
  );
}

export function VenueMap({ zones, facilities }: VenueMapProps) {
  const [selectedZone, setSelectedZone] = useState<Zone | null>(null);

  const zoneFacilities = selectedZone
    ? facilities.filter((f) => f.zone_id === selectedZone.id)
    : [];

  const handleZoneClick = (zone: Zone) => {
    setSelectedZone(selectedZone?.id === zone.id ? null : zone);
  };

  const densitySummary = {
    low: zones.filter((z) => z.density_level === 'low').length,
    medium: zones.filter((z) => z.density_level === 'medium').length,
    high: zones.filter((z) => z.density_level === 'high').length,
    critical: zones.filter((z) => z.density_level === 'critical').length,
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        {Object.entries(DENSITY_CONFIG).map(([key, cfg]) => (
          <div key={key} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium ${cfg.badge}`}>
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: cfg.stroke }} />
            {cfg.label} ({densitySummary[key as keyof typeof densitySummary]})
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 border-b border-slate-100">
          <h3 className="font-semibold text-slate-800">Live Crowd Density Map</h3>
          <p className="text-xs text-slate-400 mt-0.5">Tap a zone for details</p>
        </div>
        <div className="relative">
          <svg
            viewBox="0 0 600 440"
            className="w-full"
            style={{ background: 'linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)' }}
          >
            <defs>
              <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#e2e8f0" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="600" height="440" fill="url(#grid)" />

            <ellipse cx="300" cy="220" rx="130" ry="90" fill="#4ade80" fillOpacity={0.15} stroke="#22c55e" strokeWidth="1" />
            <ellipse cx="300" cy="220" rx="100" ry="65" fill="#86efac" fillOpacity={0.2} stroke="#4ade80" strokeWidth="0.5" />
            <rect x="230" y="185" width="140" height="70" rx="3" fill="#bbf7d0" fillOpacity={0.4} stroke="#4ade80" strokeWidth="0.5" />
            <line x1="300" y1="185" x2="300" y2="255" stroke="#4ade80" strokeWidth="0.5" strokeDasharray="3 2" />
            <line x1="230" y1="220" x2="370" y2="220" stroke="#4ade80" strokeWidth="0.5" strokeDasharray="3 2" />
            <text x="300" y="218" textAnchor="middle" fontSize="8" fill="#15803d" fontWeight="600">PLAYING FIELD</text>

            {zones.map((zone) => (
              <ZoneRect
                key={zone.id}
                zone={zone}
                isSelected={selectedZone?.id === zone.id}
                onClick={() => handleZoneClick(zone)}
              />
            ))}

            <text x="300" y="432" textAnchor="middle" fontSize="8" fill="#94a3b8">Arena Stadium - Real-time Occupancy</text>
          </svg>
        </div>
      </div>

      {selectedZone && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-slate-800">{selectedZone.name}</h3>
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${DENSITY_CONFIG[selectedZone.density_level].badge}`}>
                  {DENSITY_CONFIG[selectedZone.density_level].label}
                </span>
              </div>
              <div className="flex items-center gap-3 mt-1 text-sm text-slate-500">
                <span className="flex items-center gap-1">
                  <Users size={13} />
                  {selectedZone.current_occupancy.toLocaleString()} / {selectedZone.capacity.toLocaleString()}
                </span>
                <span>{Math.round((selectedZone.current_occupancy / selectedZone.capacity) * 100)}% full</span>
              </div>
            </div>
            <button onClick={() => setSelectedZone(null)} className="text-slate-400 hover:text-slate-600 p-1">
              <X size={18} />
            </button>
          </div>

          <div className="p-4">
            {selectedZone.density_level === 'critical' && (
              <div className="flex items-center gap-2 bg-red-50 border border-red-100 rounded-xl p-3 mb-4 text-sm text-red-700">
                <AlertTriangle size={16} className="shrink-0" />
                This zone is at critical capacity. Consider redirecting to lower-density areas.
              </div>
            )}

            {zoneFacilities.length > 0 ? (
              <div className="space-y-2">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Facilities in this zone</p>
                {zoneFacilities.map((f) => {
                  const waitColor = f.current_wait_minutes > 20 ? 'text-red-500' : f.current_wait_minutes > 10 ? 'text-amber-500' : 'text-emerald-500';
                  const statusBg = f.status === 'busy' ? 'bg-amber-50 border-amber-100' : f.status === 'open' ? 'bg-emerald-50 border-emerald-100' : 'bg-slate-50 border-slate-100';
                  return (
                    <div key={f.id} className={`flex items-center gap-3 p-3 rounded-xl border ${statusBg}`}>
                      <span className="text-xl">{FACILITY_ICONS[f.facility_type] ?? '📍'}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-800 truncate">{f.name}</p>
                        {f.location_detail && <p className="text-xs text-slate-400 truncate">{f.location_detail}</p>}
                      </div>
                      {f.current_wait_minutes > 0 && (
                        <div className="flex items-center gap-1 shrink-0">
                          <Clock size={12} className={waitColor} />
                          <span className={`text-sm font-bold ${waitColor}`}>{f.current_wait_minutes}m</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-slate-400 text-center py-4">No facility data for this zone</p>
            )}
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {zones
          .filter((z) => z.density_level === 'critical' || z.density_level === 'high')
          .map((z) => (
            <button
              key={z.id}
              onClick={() => setSelectedZone(z)}
              className="bg-white border border-slate-100 rounded-xl p-3 text-left hover:shadow-md transition-shadow"
            >
              <div className={`text-xs font-bold uppercase tracking-wide ${DENSITY_CONFIG[z.density_level].text}`}>
                {z.density_level}
              </div>
              <p className="text-sm font-semibold text-slate-800 mt-0.5">{z.name}</p>
              <p className="text-xs text-slate-400 mt-0.5">
                {Math.round((z.current_occupancy / z.capacity) * 100)}% capacity
              </p>
            </button>
          ))}
      </div>
    </div>
  );
}
