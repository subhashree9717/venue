import { MapPin, Clock, Megaphone, LayoutDashboard, Settings, TrendingUp, Users } from 'lucide-react';
import type { TabId } from '../types';

interface NavigationProps {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
  criticalCount: number;
}

const tabs: { id: TabId; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'Overview', icon: <LayoutDashboard size={20} /> },
  { id: 'insights', label: 'Insights', icon: <TrendingUp size={20} /> },
  { id: 'map', label: 'Map', icon: <MapPin size={20} /> },
  { id: 'waittimes', label: 'Waits', icon: <Clock size={20} /> },
  { id: 'staff', label: 'Staff', icon: <Users size={20} /> },
  { id: 'announcements', label: 'Updates', icon: <Megaphone size={20} /> },
  { id: 'admin', label: 'Control', icon: <Settings size={20} /> },
];

export function Navigation({ activeTab, onTabChange, criticalCount }: NavigationProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-slate-900 border-t border-slate-700 md:relative md:border-t-0 md:border-b md:border-slate-700">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-around md:justify-start md:gap-0.5 md:px-4 overflow-x-auto scrollbar-hide">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`relative flex flex-col md:flex-row items-center gap-0.5 md:gap-1.5 px-2.5 md:px-3 py-3 text-[9px] md:text-xs font-medium transition-all duration-200 shrink-0 ${
                activeTab === tab.id
                  ? 'text-blue-400 md:border-b-2 md:border-blue-400'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.icon}
              <span className="hidden md:inline">{tab.label}</span>
              <span className="md:hidden">{tab.label}</span>
              {tab.id === 'announcements' && criticalCount > 0 && (
                <span className="absolute top-1 right-1 md:top-0.5 md:right-0 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] font-bold text-white">
                  {criticalCount}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}
