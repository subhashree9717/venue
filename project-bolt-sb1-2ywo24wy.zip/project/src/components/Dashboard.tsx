import { Users, Clock, AlertTriangle, TrendingUp, Activity, Zap, Shield, ChevronRight } from 'lucide-react';
import type { Event, Zone, Facility, Announcement, TabId } from '../types';

interface DashboardProps {
  event: Event | null;
  zones: Zone[];
  facilities: Facility[];
  announcements: Announcement[];
  onNavigate: (tab: TabId) => void;
}

function StatCard({
  label, value, sub, icon, color, trend,
}: {
  label: string; value: string; sub?: string; icon: React.ReactNode; color: string; trend?: string;
}) {
  return (
    <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
      <div className="flex items-start justify-between mb-3">
        <div className={`p-2.5 rounded-xl ${color}`}>{icon}</div>
        {trend && (
          <span className="text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">{trend}</span>
        )}
      </div>
      <p className="text-2xl font-bold text-slate-900">{value}</p>
      <p className="text-sm font-medium text-slate-500 mt-0.5">{label}</p>
      {sub && <p className="text-xs text-slate-400 mt-1">{sub}</p>}
    </div>
  );
}

function ScoreBoard({ event }: { event: Event }) {
  const statusColors: Record<string, string> = {
    live: 'bg-red-500',
    pregame: 'bg-amber-500',
    halftime: 'bg-blue-500',
    finished: 'bg-slate-500',
    upcoming: 'bg-slate-400',
  };

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl p-6 text-white shadow-lg">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute -right-10 -top-10 w-64 h-64 rounded-full border-4 border-white" />
        <div className="absolute -left-5 -bottom-5 w-40 h-40 rounded-full border-2 border-white" />
      </div>
      <div className="relative">
        <div className="flex items-center gap-2 mb-5">
          <span className={`flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full ${statusColors[event.status]}`}>
            {event.status === 'live' && (
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
            )}
            {event.status.toUpperCase()}
          </span>
          {event.current_period && (
            <span className="text-xs text-slate-300">{event.current_period}</span>
          )}
        </div>

        <div className="flex items-center justify-between gap-4">
          <div className="flex-1 text-center">
            <p className="text-slate-300 text-sm font-medium mb-1">{event.home_team}</p>
            <p className="text-5xl font-black tracking-tight">{event.home_score}</p>
          </div>
          <div className="text-slate-500 text-xl font-light">vs</div>
          <div className="flex-1 text-center">
            <p className="text-slate-300 text-sm font-medium mb-1">{event.away_team}</p>
            <p className="text-5xl font-black tracking-tight">{event.away_score}</p>
          </div>
        </div>

        <div className="mt-5 pt-4 border-t border-slate-700 flex items-center justify-between text-sm">
          <span className="text-slate-400">{event.venue_name}</span>
          <span className="text-slate-400">{event.name}</span>
        </div>
      </div>
    </div>
  );
}

export function Dashboard({ event, zones, facilities, announcements, onNavigate }: DashboardProps) {
  const criticalZones = zones.filter((z) => z.density_level === 'critical');
  const highZones = zones.filter((z) => z.density_level === 'high');
  const totalOccupancy = zones.reduce((sum, z) => sum + z.current_occupancy, 0);
  const totalCapacity = zones.reduce((sum, z) => sum + z.capacity, 0);
  const occupancyPct = totalCapacity > 0 ? Math.round((totalOccupancy / totalCapacity) * 100) : 0;
  const avgWait = facilities.length > 0
    ? Math.round(facilities.filter((f) => f.facility_type === 'concession').reduce((sum, f) => sum + f.current_wait_minutes, 0) / Math.max(1, facilities.filter((f) => f.facility_type === 'concession').length))
    : 0;
  const busyFacilities = facilities.filter((f) => f.status === 'busy' || f.current_wait_minutes > 15);
  const criticalAnnouncements = announcements.filter((a) => a.priority === 'critical');

  const densityColors: Record<string, string> = {
    low: 'bg-emerald-100 text-emerald-700',
    medium: 'bg-amber-100 text-amber-700',
    high: 'bg-orange-100 text-orange-700',
    critical: 'bg-red-100 text-red-700',
  };

  return (
    <div className="space-y-6">
      {event && <ScoreBoard event={event} />}

      {criticalAnnouncements.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle size={20} className="text-red-500 mt-0.5 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-red-800 text-sm">{criticalAnnouncements[0].title}</p>
              <p className="text-red-600 text-sm mt-0.5 line-clamp-2">{criticalAnnouncements[0].message}</p>
            </div>
            <button onClick={() => onNavigate('announcements')} className="shrink-0 text-red-500 hover:text-red-700">
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard
          label="Attendance"
          value={totalOccupancy.toLocaleString()}
          sub={`${occupancyPct}% capacity`}
          icon={<Users size={18} className="text-blue-600" />}
          color="bg-blue-50"
          trend={`+${Math.round(occupancyPct * 0.3)}%`}
        />
        <StatCard
          label="Avg Wait Time"
          value={`${avgWait}m`}
          sub="Concessions"
          icon={<Clock size={18} className="text-amber-600" />}
          color="bg-amber-50"
        />
        <StatCard
          label="Critical Zones"
          value={String(criticalZones.length + highZones.length)}
          sub={`${criticalZones.length} critical, ${highZones.length} high`}
          icon={<AlertTriangle size={18} className="text-red-500" />}
          color="bg-red-50"
        />
        <StatCard
          label="Busy Facilities"
          value={String(busyFacilities.length)}
          sub={`of ${facilities.length} total`}
          icon={<Activity size={18} className="text-orange-500" />}
          color="bg-orange-50"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-800">Zone Status</h3>
            <button onClick={() => onNavigate('map')} className="text-xs text-blue-500 font-medium flex items-center gap-1 hover:text-blue-700">
              View map <ChevronRight size={14} />
            </button>
          </div>
          <div className="space-y-2">
            {zones.slice(0, 6).map((zone) => {
              const pct = Math.round((zone.current_occupancy / zone.capacity) * 100);
              const barColors: Record<string, string> = {
                low: 'bg-emerald-400',
                medium: 'bg-amber-400',
                high: 'bg-orange-400',
                critical: 'bg-red-500',
              };
              return (
                <div key={zone.id}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-slate-700">{zone.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-400">{pct}%</span>
                      <span className={`text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded-full ${densityColors[zone.density_level]}`}>
                        {zone.density_level}
                      </span>
                    </div>
                  </div>
                  <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${barColors[zone.density_level]}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-800">Longest Waits</h3>
            <button onClick={() => onNavigate('waittimes')} className="text-xs text-blue-500 font-medium flex items-center gap-1 hover:text-blue-700">
              All times <ChevronRight size={14} />
            </button>
          </div>
          <div className="space-y-3">
            {[...facilities]
              .sort((a, b) => b.current_wait_minutes - a.current_wait_minutes)
              .slice(0, 5)
              .map((f) => {
                const waitColor = f.current_wait_minutes > 20 ? 'text-red-500' : f.current_wait_minutes > 10 ? 'text-amber-500' : 'text-emerald-500';
                return (
                  <div key={f.id} className="flex items-center justify-between py-1">
                    <div>
                      <p className="text-sm font-medium text-slate-800 line-clamp-1">{f.name}</p>
                      <p className="text-xs text-slate-400 capitalize">{f.facility_type.replace('_', ' ')}</p>
                    </div>
                    <span className={`text-lg font-bold ${waitColor}`}>
                      {f.current_wait_minutes}m
                    </span>
                  </div>
                );
              })}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <button
          onClick={() => onNavigate('map')}
          className="flex items-center gap-3 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl p-4 transition-colors text-left"
        >
          <TrendingUp size={22} />
          <div>
            <p className="font-semibold">Live Crowd Map</p>
            <p className="text-blue-200 text-xs">View density heatmap</p>
          </div>
        </button>
        <button
          onClick={() => onNavigate('waittimes')}
          className="flex items-center gap-3 bg-amber-500 hover:bg-amber-600 text-white rounded-2xl p-4 transition-colors text-left"
        >
          <Zap size={22} />
          <div>
            <p className="font-semibold">Beat the Queue</p>
            <p className="text-amber-100 text-xs">Find shortest wait</p>
          </div>
        </button>
        <button
          onClick={() => onNavigate('announcements')}
          className="flex items-center gap-3 bg-slate-800 hover:bg-slate-700 text-white rounded-2xl p-4 transition-colors text-left"
        >
          <Shield size={22} />
          <div>
            <p className="font-semibold">Live Updates</p>
            <p className="text-slate-300 text-xs">{announcements.length} active alerts</p>
          </div>
        </button>
      </div>
    </div>
  );
}
