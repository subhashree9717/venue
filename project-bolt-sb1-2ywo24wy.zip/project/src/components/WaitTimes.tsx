import { useState } from 'react';
import { Clock, CheckCircle, AlertCircle, XCircle, ChevronDown, Zap } from 'lucide-react';
import type { Facility, FacilityType, Zone } from '../types';

interface WaitTimesProps {
  facilities: Facility[];
  zones: Zone[];
}

const FACILITY_LABELS: Record<FacilityType, string> = {
  concession: 'Concessions',
  restroom: 'Restrooms',
  first_aid: 'First Aid',
  exit: 'Exits',
  gate: 'Gates',
  merchandise: 'Merchandise',
};

const FACILITY_EMOJIS: Record<FacilityType, string> = {
  concession: '🍔',
  restroom: '🚻',
  first_aid: '🏥',
  exit: '🚪',
  gate: '🚪',
  merchandise: '👕',
};

function WaitBar({ minutes }: { minutes: number }) {
  const maxMinutes = 40;
  const pct = Math.min(100, (minutes / maxMinutes) * 100);
  const color = minutes > 20 ? 'bg-red-400' : minutes > 10 ? 'bg-amber-400' : 'bg-emerald-400';
  return (
    <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden flex-1">
      <div className={`h-full rounded-full transition-all duration-700 ${color}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

function StatusBadge({ status }: { status: Facility['status'] }) {
  const configs = {
    open: { icon: <CheckCircle size={12} />, label: 'Open', cls: 'text-emerald-600 bg-emerald-50' },
    busy: { icon: <AlertCircle size={12} />, label: 'Busy', cls: 'text-amber-600 bg-amber-50' },
    closed: { icon: <XCircle size={12} />, label: 'Closed', cls: 'text-red-600 bg-red-50' },
    maintenance: { icon: <XCircle size={12} />, label: 'Maintenance', cls: 'text-slate-500 bg-slate-100' },
  };
  const cfg = configs[status];
  return (
    <span className={`flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full ${cfg.cls}`}>
      {cfg.icon} {cfg.label}
    </span>
  );
}

function FacilityCard({ facility, zone }: { facility: Facility; zone?: Zone }) {
  const waitColor = facility.current_wait_minutes > 20 ? 'text-red-500' : facility.current_wait_minutes > 10 ? 'text-amber-500' : 'text-emerald-600';

  return (
    <div className="bg-white rounded-xl border border-slate-100 p-4 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-start gap-3">
          <span className="text-2xl">{FACILITY_EMOJIS[facility.facility_type]}</span>
          <div>
            <p className="font-semibold text-slate-800 text-sm leading-tight">{facility.name}</p>
            {facility.location_detail && (
              <p className="text-xs text-slate-400 mt-0.5">{facility.location_detail}</p>
            )}
            {zone && (
              <p className="text-xs text-blue-500 mt-0.5">{zone.name}</p>
            )}
          </div>
        </div>
        <StatusBadge status={facility.status} />
      </div>

      <div className="flex items-center gap-3">
        <WaitBar minutes={facility.current_wait_minutes} />
        <div className="flex items-center gap-1 shrink-0">
          <Clock size={13} className={waitColor} />
          <span className={`font-bold text-sm ${waitColor}`}>
            {facility.current_wait_minutes === 0 ? 'No wait' : `${facility.current_wait_minutes}m`}
          </span>
        </div>
      </div>

      {facility.description && (
        <p className="text-xs text-slate-400 mt-2">{facility.description}</p>
      )}
    </div>
  );
}

export function WaitTimes({ facilities, zones }: WaitTimesProps) {
  const [activeType, setActiveType] = useState<FacilityType | 'all'>('all');
  const [sortBy, setSortBy] = useState<'wait' | 'name'>('wait');

  const types: (FacilityType | 'all')[] = ['all', 'concession', 'restroom', 'gate', 'merchandise', 'first_aid'];

  const filtered = facilities
    .filter((f) => activeType === 'all' || f.facility_type === activeType)
    .sort((a, b) => sortBy === 'wait' ? b.current_wait_minutes - a.current_wait_minutes : a.name.localeCompare(b.name));

  const bestOption = facilities
    .filter((f) => f.facility_type === 'concession' && f.status !== 'closed')
    .sort((a, b) => a.current_wait_minutes - b.current_wait_minutes)[0];

  const getZone = (zoneId: string) => zones.find((z) => z.id === zoneId);

  const avgWaits: Record<string, number> = {};
  for (const type of ['concession', 'restroom', 'gate'] as FacilityType[]) {
    const items = facilities.filter((f) => f.facility_type === type);
    avgWaits[type] = items.length ? Math.round(items.reduce((s, f) => s + f.current_wait_minutes, 0) / items.length) : 0;
  }

  return (
    <div className="space-y-5">
      {bestOption && (
        <div className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Zap size={16} />
            <span className="text-sm font-semibold">Best Pick Right Now</span>
          </div>
          <p className="font-bold text-lg">{bestOption.name}</p>
          <p className="text-emerald-100 text-sm">{getZone(bestOption.zone_id)?.name} — Only {bestOption.current_wait_minutes} min wait</p>
        </div>
      )}

      <div className="grid grid-cols-3 gap-3">
        {(['concession', 'restroom', 'gate'] as FacilityType[]).map((type) => (
          <div key={type} className="bg-white rounded-xl border border-slate-100 p-3 text-center">
            <p className="text-2xl mb-1">{FACILITY_EMOJIS[type]}</p>
            <p className={`text-lg font-bold ${avgWaits[type] > 15 ? 'text-red-500' : avgWaits[type] > 8 ? 'text-amber-500' : 'text-emerald-600'}`}>
              {avgWaits[type]}m
            </p>
            <p className="text-xs text-slate-400">avg {FACILITY_LABELS[type]}</p>
          </div>
        ))}
      </div>

      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-hide">
        {types.map((t) => (
          <button
            key={t}
            onClick={() => setActiveType(t)}
            className={`shrink-0 px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
              activeType === t
                ? 'bg-slate-900 text-white'
                : 'bg-white border border-slate-200 text-slate-600 hover:border-slate-400'
            }`}
          >
            {t === 'all' ? 'All' : FACILITY_LABELS[t]}
          </button>
        ))}
        <div className="flex items-center gap-1 ml-auto shrink-0">
          <button
            onClick={() => setSortBy(sortBy === 'wait' ? 'name' : 'wait')}
            className="flex items-center gap-1 text-xs text-slate-500 border border-slate-200 rounded-full px-3 py-1.5 bg-white hover:border-slate-400"
          >
            Sort: {sortBy === 'wait' ? 'Wait time' : 'Name'}
            <ChevronDown size={12} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {filtered.map((f) => (
          <FacilityCard key={f.id} facility={f} zone={getZone(f.zone_id)} />
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 text-slate-400">
          <Clock size={40} className="mx-auto mb-3 opacity-30" />
          <p>No facilities found</p>
        </div>
      )}
    </div>
  );
}
