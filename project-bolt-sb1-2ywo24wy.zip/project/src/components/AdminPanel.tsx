import { useState } from 'react';
import { Settings, Sliders, Megaphone, CheckCircle, ChevronDown } from 'lucide-react';
import type { Zone, Facility, Announcement, Event } from '../types';

interface AdminPanelProps {
  event: Event | null;
  zones: Zone[];
  facilities: Facility[];
  onUpdateZone: (id: string, occupancy: number, density: Zone['density_level']) => Promise<void>;
  onUpdateFacility: (id: string, wait: number, status: Facility['status']) => Promise<void>;
  onAddAnnouncement: (eventId: string, title: string, message: string, priority: Announcement['priority']) => Promise<void>;
}

function computeDensity(occupancy: number, capacity: number): Zone['density_level'] {
  const pct = occupancy / capacity;
  if (pct >= 0.9) return 'critical';
  if (pct >= 0.75) return 'high';
  if (pct >= 0.5) return 'medium';
  return 'low';
}

function SectionHeader({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-2 mb-3">
      <div className="h-px flex-1 bg-slate-100" />
      <span className="text-xs font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap">{children}</span>
      <div className="h-px flex-1 bg-slate-100" />
    </div>
  );
}

export function AdminPanel({ event, zones, facilities, onUpdateZone, onUpdateFacility, onAddAnnouncement }: AdminPanelProps) {
  const [savedId, setSavedId] = useState<string | null>(null);
  const [anTitle, setAnTitle] = useState('');
  const [anMessage, setAnMessage] = useState('');
  const [anPriority, setAnPriority] = useState<Announcement['priority']>('info');
  const [posting, setPosting] = useState(false);
  const [posted, setPosted] = useState(false);

  const handleZoneChange = async (zone: Zone, newOccupancy: number) => {
    const density = computeDensity(newOccupancy, zone.capacity);
    await onUpdateZone(zone.id, newOccupancy, density);
    setSavedId(zone.id);
    setTimeout(() => setSavedId(null), 2000);
  };

  const handleFacilityWaitChange = async (facility: Facility, newWait: number) => {
    const status: Facility['status'] = newWait > 15 ? 'busy' : newWait === 0 ? 'open' : 'open';
    await onUpdateFacility(facility.id, newWait, status);
    setSavedId(facility.id);
    setTimeout(() => setSavedId(null), 2000);
  };

  const handlePostAnnouncement = async () => {
    if (!event || !anTitle.trim() || !anMessage.trim()) return;
    setPosting(true);
    await onAddAnnouncement(event.id, anTitle.trim(), anMessage.trim(), anPriority);
    setAnTitle('');
    setAnMessage('');
    setPosting(false);
    setPosted(true);
    setTimeout(() => setPosted(false), 3000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 bg-slate-900 text-white rounded-2xl p-4">
        <div className="p-2 bg-white/10 rounded-xl">
          <Settings size={20} />
        </div>
        <div>
          <p className="font-semibold">Operations Control Center</p>
          <p className="text-slate-300 text-sm">Manage zones, facilities, and communications</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center gap-2">
          <Megaphone size={16} className="text-slate-500" />
          <h3 className="font-semibold text-slate-800">Broadcast Announcement</h3>
        </div>
        <div className="p-4 space-y-3">
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide block mb-1">Priority Level</label>
            <div className="flex gap-2">
              {(['info', 'warning', 'critical'] as Announcement['priority'][]).map((p) => {
                const colors: Record<string, string> = {
                  info: 'border-blue-400 bg-blue-50 text-blue-700',
                  warning: 'border-amber-400 bg-amber-50 text-amber-700',
                  critical: 'border-red-400 bg-red-50 text-red-700',
                };
                return (
                  <button
                    key={p}
                    onClick={() => setAnPriority(p)}
                    className={`flex-1 py-2 rounded-xl border-2 text-sm font-semibold capitalize transition-all ${
                      anPriority === p ? colors[p] : 'border-slate-200 text-slate-500 bg-slate-50'
                    }`}
                  >
                    {p}
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide block mb-1">Title</label>
            <input
              value={anTitle}
              onChange={(e) => setAnTitle(e.target.value)}
              placeholder="e.g. Gate A Closure Notice"
              className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-800 placeholder-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide block mb-1">Message</label>
            <textarea
              value={anMessage}
              onChange={(e) => setAnMessage(e.target.value)}
              placeholder="Enter the full announcement message..."
              rows={3}
              className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-800 placeholder-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
            />
          </div>
          <button
            onClick={handlePostAnnouncement}
            disabled={posting || !anTitle.trim() || !anMessage.trim() || !event}
            className={`w-full py-3 rounded-xl font-semibold text-sm transition-all ${
              posted
                ? 'bg-emerald-500 text-white'
                : 'bg-slate-900 hover:bg-slate-700 text-white disabled:bg-slate-200 disabled:text-slate-400'
            }`}
          >
            {posting ? 'Broadcasting...' : posted ? '✓ Announcement Posted' : 'Broadcast to All Attendees'}
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center gap-2">
          <Sliders size={16} className="text-slate-500" />
          <h3 className="font-semibold text-slate-800">Zone Occupancy Control</h3>
        </div>
        <div className="p-4 space-y-4">
          {zones.map((zone) => {
            const pct = Math.round((zone.current_occupancy / zone.capacity) * 100);
            const densityColors: Record<string, string> = {
              low: 'text-emerald-600',
              medium: 'text-amber-600',
              high: 'text-orange-600',
              critical: 'text-red-600',
            };
            return (
              <div key={zone.id}>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-slate-700">{zone.name}</span>
                    <span className={`text-xs font-bold uppercase ${densityColors[zone.density_level]}`}>
                      {zone.density_level}
                    </span>
                    {savedId === zone.id && (
                      <CheckCircle size={14} className="text-emerald-500" />
                    )}
                  </div>
                  <span className="text-xs text-slate-400">{zone.current_occupancy.toLocaleString()} / {zone.capacity.toLocaleString()} ({pct}%)</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={zone.capacity}
                  step={100}
                  value={zone.current_occupancy}
                  onChange={(e) => handleZoneChange(zone, Number(e.target.value))}
                  className="w-full accent-blue-600 h-2 rounded-full"
                />
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center gap-2">
          <ChevronDown size={16} className="text-slate-500" />
          <h3 className="font-semibold text-slate-800">Facility Wait Times</h3>
        </div>
        <div className="p-4">
          <SectionHeader>Concessions</SectionHeader>
          <div className="space-y-4 mb-5">
            {facilities.filter((f) => f.facility_type === 'concession').map((f) => (
              <div key={f.id}>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-700 truncate max-w-[200px]">{f.name}</span>
                    {savedId === f.id && <CheckCircle size={14} className="text-emerald-500 shrink-0" />}
                  </div>
                  <span className={`text-sm font-bold ${f.current_wait_minutes > 20 ? 'text-red-500' : f.current_wait_minutes > 10 ? 'text-amber-500' : 'text-emerald-600'}`}>
                    {f.current_wait_minutes}m
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={40}
                  step={1}
                  value={f.current_wait_minutes}
                  onChange={(e) => handleFacilityWaitChange(f, Number(e.target.value))}
                  className="w-full accent-blue-600 h-2 rounded-full"
                />
              </div>
            ))}
          </div>

          <SectionHeader>Restrooms & Gates</SectionHeader>
          <div className="space-y-4">
            {facilities.filter((f) => f.facility_type === 'restroom' || f.facility_type === 'gate').map((f) => (
              <div key={f.id}>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-700 truncate max-w-[200px]">{f.name}</span>
                    {savedId === f.id && <CheckCircle size={14} className="text-emerald-500 shrink-0" />}
                  </div>
                  <span className={`text-sm font-bold ${f.current_wait_minutes > 20 ? 'text-red-500' : f.current_wait_minutes > 10 ? 'text-amber-500' : 'text-emerald-600'}`}>
                    {f.current_wait_minutes}m
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={40}
                  step={1}
                  value={f.current_wait_minutes}
                  onChange={(e) => handleFacilityWaitChange(f, Number(e.target.value))}
                  className="w-full accent-blue-600 h-2 rounded-full"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
