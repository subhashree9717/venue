import { Users, MapPin, Clock, AlertCircle, Radio, CheckCircle, PhoneOff, Zap } from 'lucide-react';
import type { StaffAssignment, Zone } from '../types';

interface StaffCoordinationProps {
  staff: StaffAssignment[];
  zones: Zone[];
}

const ROLE_COLORS: Record<string, string> = {
  crowd_control: 'bg-orange-100 text-orange-700',
  medical: 'bg-red-100 text-red-700',
  vendor_support: 'bg-blue-100 text-blue-700',
  security: 'bg-slate-100 text-slate-700',
  maintenance: 'bg-amber-100 text-amber-700',
  guest_services: 'bg-emerald-100 text-emerald-700',
};

const STATUS_ICONS: Record<string, React.ReactNode> = {
  available: <CheckCircle size={14} className="text-emerald-600" />,
  break: <Clock size={14} className="text-slate-400" />,
  assigned: <Radio size={14} className="text-blue-600" />,
  'en-route': <Zap size={14} className="text-amber-600" />,
  'on-scene': <AlertCircle size={14} className="text-red-600" />,
  'off-duty': <PhoneOff size={14} className="text-slate-400" />,
};

const STATUS_LABELS: Record<string, string> = {
  available: 'Available',
  break: 'On Break',
  assigned: 'Assigned',
  'en-route': 'En Route',
  'on-scene': 'On Scene',
  'off-duty': 'Off Duty',
};

function WorkloadIndicator({ percentage }: { percentage: number }) {
  const color = percentage > 80 ? 'text-red-600' : percentage > 60 ? 'text-amber-600' : 'text-emerald-600';
  return (
    <div className="flex items-center gap-1.5">
      <div className="h-1.5 w-16 bg-slate-100 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${percentage > 80 ? 'bg-red-500' : percentage > 60 ? 'bg-amber-500' : 'bg-emerald-500'}`}
          style={{ width: `${percentage}%` }}
        />
      </div>
      <span className={`text-xs font-bold ${color}`}>{percentage}%</span>
    </div>
  );
}

function StaffCard({ staff, zone }: { staff: StaffAssignment; zone?: Zone }) {
  const roleColor = ROLE_COLORS[staff.role];
  const statusIcon = STATUS_ICONS[staff.status];
  const statusLabel = STATUS_LABELS[staff.status];

  return (
    <div className="bg-white rounded-xl border border-slate-100 p-3 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-2">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${roleColor}`}>
              {staff.role.replace('_', ' ').toUpperCase()}
            </span>
          </div>
          <p className="font-semibold text-slate-800 text-sm">{staff.staff_name}</p>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-500">
          {statusIcon}
          <span className="font-medium">{statusLabel}</span>
        </div>
      </div>

      {zone && (
        <div className="flex items-center gap-1.5 mb-2 text-xs text-slate-600">
          <MapPin size={12} />
          {zone.name}
        </div>
      )}

      {staff.current_task && (
        <p className="text-xs text-slate-600 bg-slate-50 rounded px-2 py-1 mb-2 line-clamp-2">
          {staff.current_task}
        </p>
      )}

      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-slate-500">Workload</span>
        <WorkloadIndicator percentage={staff.workload_percentage} />
      </div>

      {staff.task_priority && (
        <div className="mt-2 pt-2 border-t border-slate-100">
          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase ${
            staff.task_priority === 'critical' ? 'bg-red-100 text-red-700'
              : staff.task_priority === 'high' ? 'bg-orange-100 text-orange-700'
              : staff.task_priority === 'medium' ? 'bg-amber-100 text-amber-700'
              : 'bg-slate-100 text-slate-700'
          }`}>
            {staff.task_priority} Priority
          </span>
        </div>
      )}
    </div>
  );
}

export function StaffCoordination({ staff, zones }: StaffCoordinationProps) {
  const onScene = staff.filter((s) => s.status === 'on-scene' || s.status === 'en-route');
  const assigned = staff.filter((s) => s.status === 'assigned');
  const available = staff.filter((s) => s.status === 'available');
  const onBreak = staff.filter((s) => s.status === 'break');

  const criticalTasks = staff.filter((s) => s.task_priority === 'critical');
  const highWorkload = staff.filter((s) => s.workload_percentage > 80);
  const avgWorkload = Math.round(staff.reduce((sum, s) => sum + s.workload_percentage, 0) / Math.max(1, staff.length));

  const getZone = (zoneId?: string) => zoneId ? zones.find((z) => z.id === zoneId) : undefined;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-white rounded-xl border border-slate-100 p-3 text-center">
          <p className="text-2xl font-bold text-slate-900">{staff.length}</p>
          <p className="text-xs text-slate-500 mt-1">Total Staff</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-100 p-3 text-center">
          <p className="text-2xl font-bold text-red-600">{onScene.length}</p>
          <p className="text-xs text-slate-500 mt-1">On Scene</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-100 p-3 text-center">
          <p className="text-2xl font-bold text-blue-600">{assigned.length}</p>
          <p className="text-xs text-slate-500 mt-1">Assigned</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-100 p-3 text-center">
          <p className={`text-2xl font-bold ${avgWorkload > 80 ? 'text-red-600' : avgWorkload > 60 ? 'text-amber-600' : 'text-emerald-600'}`}>
            {avgWorkload}%
          </p>
          <p className="text-xs text-slate-500 mt-1">Avg Workload</p>
        </div>
      </div>

      {criticalTasks.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-4">
          <div className="flex items-start gap-3">
            <AlertCircle size={18} className="text-red-600 mt-0.5 shrink-0" />
            <div>
              <p className="font-bold text-red-800">Critical Tasks in Progress</p>
              <div className="space-y-2 mt-2">
                {criticalTasks.map((s) => (
                  <div key={s.id} className="text-sm text-red-700">
                    <span className="font-semibold">{s.staff_name}</span>
                    {s.current_task && ` — ${s.current_task}`}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {highWorkload.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4">
          <p className="font-bold text-amber-800 mb-2">High Workload Alert</p>
          <p className="text-sm text-amber-700 mb-3">
            {highWorkload.length} staff member{highWorkload.length !== 1 ? 's' : ''} over 80% capacity. Consider load redistribution.
          </p>
          <div className="space-y-2">
            {highWorkload.map((s) => (
              <div key={s.id} className="text-sm bg-white/60 rounded p-2">
                <span className="font-semibold text-amber-800">{s.staff_name}</span>
                <span className="text-amber-700 ml-2">{s.role.replace('_', ' ')}</span>
                <span className="text-amber-600 float-right">{s.workload_percentage}%</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-4">
        {onScene.length > 0 && (
          <div>
            <h3 className="font-bold text-slate-800 mb-3 text-sm uppercase tracking-wide flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              On Scene / En Route
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {onScene.map((s) => (
                <StaffCard key={s.id} staff={s} zone={getZone(s.location_zone)} />
              ))}
            </div>
          </div>
        )}

        {assigned.length > 0 && (
          <div>
            <h3 className="font-bold text-slate-800 mb-3 text-sm uppercase tracking-wide flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-blue-500" />
              Assigned to Tasks
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {assigned.map((s) => (
                <StaffCard key={s.id} staff={s} zone={getZone(s.location_zone)} />
              ))}
            </div>
          </div>
        )}

        {available.length > 0 && (
          <div>
            <h3 className="font-bold text-slate-800 mb-3 text-sm uppercase tracking-wide flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              Available
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {available.map((s) => (
                <StaffCard key={s.id} staff={s} zone={getZone(s.location_zone)} />
              ))}
            </div>
          </div>
        )}

        {onBreak.length > 0 && (
          <div>
            <h3 className="font-bold text-slate-800 mb-3 text-sm uppercase tracking-wide flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-slate-400" />
              On Break
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {onBreak.map((s) => (
                <StaffCard key={s.id} staff={s} zone={getZone(s.location_zone)} />
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4">
        <div className="flex items-start gap-3">
          <Users size={18} className="text-blue-600 mt-0.5 shrink-0" />
          <div>
            <p className="font-bold text-blue-900">Team Performance</p>
            <div className="space-y-2 mt-2 text-sm text-blue-800">
              <p>• {onScene.length} staff actively responding to crowd issues</p>
              <p>• Average workload utilization: {avgWorkload}% (optimal: 60-75%)</p>
              <p>• {available.length} staff available for reassignment</p>
              <p>• {criticalTasks.length} critical task{criticalTasks.length !== 1 ? 's' : ''} ongoing</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
