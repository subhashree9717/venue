import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { Event, Zone, Facility, Announcement, CrowdPrediction, CrowdAnomaly, StaffAssignment, ZoneHistory, FacilityPerformance } from '../types';

export function useVenueData() {
  const [event, setEvent] = useState<Event | null>(null);
  const [zones, setZones] = useState<Zone[]>([]);
  const [facilities, setFacilities] = useState<Facility[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [predictions, setPredictions] = useState<CrowdPrediction[]>([]);
  const [anomalies, setAnomalies] = useState<CrowdAnomaly[]>([]);
  const [staff, setStaff] = useState<StaffAssignment[]>([]);
  const [zoneHistory, setZoneHistory] = useState<ZoneHistory[]>([]);
  const [facilityPerformance, setFacilityPerformance] = useState<FacilityPerformance[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAll = useCallback(async () => {
    try {
      const [evtRes, zoneRes, facRes, annRes, predRes, anomRes, staffRes, histRes, perfRes] = await Promise.all([
        supabase.from('events').select('*').eq('status', 'live').maybeSingle(),
        supabase.from('zones').select('*').order('name'),
        supabase.from('facilities').select('*').order('name'),
        supabase.from('announcements').select('*').eq('is_active', true).order('created_at', { ascending: false }),
        supabase.from('crowd_predictions').select('*').order('predicted_at', { ascending: false }).limit(20),
        supabase.from('crowd_anomalies').select('*').eq('resolved', false).order('created_at', { ascending: false }),
        supabase.from('staff_assignments').select('*').order('created_at', { ascending: false }),
        supabase.from('zone_history').select('*').order('snapshot_time', { ascending: false }).limit(30),
        supabase.from('facility_performance').select('*').order('updated_at', { ascending: false }).limit(10),
      ]);

      if (evtRes.error) throw evtRes.error;
      if (zoneRes.error) throw zoneRes.error;
      if (facRes.error) throw facRes.error;
      if (annRes.error) throw annRes.error;
      if (predRes.error) throw predRes.error;
      if (anomRes.error) throw anomRes.error;
      if (staffRes.error) throw staffRes.error;
      if (histRes.error) throw histRes.error;
      if (perfRes.error) throw perfRes.error;

      setEvent(evtRes.data);
      setZones(zoneRes.data ?? []);
      setFacilities(facRes.data ?? []);
      setAnnouncements(annRes.data ?? []);
      setPredictions(predRes.data ?? []);
      setAnomalies(anomRes.data ?? []);
      setStaff(staffRes.data ?? []);
      setZoneHistory(histRes.data ?? []);
      setFacilityPerformance(perfRes.data ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load venue data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAll();

    const zonesChannel = supabase
      .channel('zones-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'zones' }, () => {
        supabase.from('zones').select('*').order('name').then(({ data }) => {
          if (data) setZones(data);
        });
      })
      .subscribe();

    const facilitiesChannel = supabase
      .channel('facilities-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'facilities' }, () => {
        supabase.from('facilities').select('*').order('name').then(({ data }) => {
          if (data) setFacilities(data);
        });
      })
      .subscribe();

    const announcementsChannel = supabase
      .channel('announcements-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'announcements' }, () => {
        supabase.from('announcements').select('*').eq('is_active', true).order('created_at', { ascending: false }).then(({ data }) => {
          if (data) setAnnouncements(data);
        });
      })
      .subscribe();

    const predictionsChannel = supabase
      .channel('predictions-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'crowd_predictions' }, () => {
        supabase.from('crowd_predictions').select('*').order('predicted_at', { ascending: false }).limit(20).then(({ data }) => {
          if (data) setPredictions(data);
        });
      })
      .subscribe();

    const anomaliesChannel = supabase
      .channel('anomalies-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'crowd_anomalies' }, () => {
        supabase.from('crowd_anomalies').select('*').eq('resolved', false).order('created_at', { ascending: false }).then(({ data }) => {
          if (data) setAnomalies(data);
        });
      })
      .subscribe();

    const staffChannel = supabase
      .channel('staff-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'staff_assignments' }, () => {
        supabase.from('staff_assignments').select('*').order('created_at', { ascending: false }).then(({ data }) => {
          if (data) setStaff(data);
        });
      })
      .subscribe();

    const eventsChannel = supabase
      .channel('events-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'events' }, () => {
        supabase.from('events').select('*').eq('status', 'live').maybeSingle().then(({ data }) => {
          setEvent(data);
        });
      })
      .subscribe();

    return () => {
      supabase.removeChannel(zonesChannel);
      supabase.removeChannel(facilitiesChannel);
      supabase.removeChannel(announcementsChannel);
      supabase.removeChannel(predictionsChannel);
      supabase.removeChannel(anomaliesChannel);
      supabase.removeChannel(staffChannel);
      supabase.removeChannel(eventsChannel);
    };
  }, [fetchAll]);

  const updateZoneDensity = async (zoneId: string, occupancy: number, density: Zone['density_level']) => {
    await supabase
      .from('zones')
      .update({ current_occupancy: occupancy, density_level: density, updated_at: new Date().toISOString() })
      .eq('id', zoneId);
  };

  const updateFacilityWait = async (facilityId: string, waitMinutes: number, status: Facility['status']) => {
    await supabase
      .from('facilities')
      .update({ current_wait_minutes: waitMinutes, status, updated_at: new Date().toISOString() })
      .eq('id', facilityId);
  };

  const addAnnouncement = async (eventId: string, title: string, message: string, priority: Announcement['priority']) => {
    await supabase.from('announcements').insert({
      event_id: eventId,
      title,
      message,
      priority,
      expires_at: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(),
    });
  };

  const dismissAnnouncement = async (id: string) => {
    await supabase.from('announcements').update({ is_active: false }).eq('id', id);
  };

  return {
    event, zones, facilities, announcements, predictions, anomalies, staff, zoneHistory, facilityPerformance,
    loading, error,
    updateZoneDensity, updateFacilityWait, addAnnouncement, dismissAnnouncement,
    refetch: fetchAll,
  };
}
