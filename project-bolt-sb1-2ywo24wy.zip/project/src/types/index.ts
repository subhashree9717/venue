export type DensityLevel = 'low' | 'medium' | 'high' | 'critical';
export type FacilityType = 'concession' | 'restroom' | 'first_aid' | 'exit' | 'gate' | 'merchandise';
export type FacilityStatus = 'open' | 'busy' | 'closed' | 'maintenance';
export type EventStatus = 'upcoming' | 'pregame' | 'live' | 'halftime' | 'finished';
export type AnnouncementPriority = 'info' | 'warning' | 'critical';
export type AlertType = 'crowd_surge' | 'medical' | 'security' | 'facility' | 'general';

export interface Event {
  id: string;
  name: string;
  venue_name: string;
  sport_type: string;
  home_team: string;
  away_team: string;
  home_score: number;
  away_score: number;
  scheduled_at: string;
  status: EventStatus;
  current_period: string | null;
  attendance: number;
  capacity: number;
  created_at: string;
}

export interface Zone {
  id: string;
  event_id: string;
  name: string;
  section_code: string;
  capacity: number;
  current_occupancy: number;
  density_level: DensityLevel;
  x_position: number;
  y_position: number;
  width: number;
  height: number;
  color_override: string | null;
  created_at: string;
  updated_at: string;
}

export interface Facility {
  id: string;
  zone_id: string;
  facility_type: FacilityType;
  name: string;
  description: string | null;
  current_wait_minutes: number;
  status: FacilityStatus;
  staff_count: number;
  location_detail: string | null;
  created_at: string;
  updated_at: string;
}

export interface Announcement {
  id: string;
  event_id: string;
  title: string;
  message: string;
  priority: AnnouncementPriority;
  target_zones: string[];
  expires_at: string | null;
  is_active: boolean;
  created_at: string;
}

export interface StaffAlert {
  id: string;
  event_id: string;
  zone_id: string | null;
  alert_type: AlertType;
  message: string;
  priority: string;
  acknowledged: boolean;
  acknowledged_at: string | null;
  created_at: string;
}

export interface ZoneWithFacilities extends Zone {
  facilities: Facility[];
}

export interface CrowdPrediction {
  id: string;
  zone_id: string;
  event_id: string;
  predicted_occupancy: number;
  confidence_score: number;
  time_horizon: '15min' | '1hour' | '4hour';
  trend_direction: 'increasing' | 'stable' | 'decreasing';
  predicted_at: string;
  created_at: string;
}

export interface CrowdAnomaly {
  id: string;
  event_id: string;
  zone_id: string;
  anomaly_type: 'surge' | 'bottleneck' | 'evacuation' | 'unusual_pattern' | 'congestion_peak';
  severity: 'minor' | 'moderate' | 'severe' | 'critical';
  description: string;
  predicted_peak_occupancy?: number;
  mitigation_suggested?: string;
  resolved: boolean;
  resolved_at?: string;
  created_at: string;
}

export interface StaffAssignment {
  id: string;
  event_id: string;
  zone_id?: string;
  staff_name: string;
  role: 'crowd_control' | 'medical' | 'vendor_support' | 'security' | 'maintenance' | 'guest_services';
  status: 'available' | 'break' | 'assigned' | 'en-route' | 'on-scene' | 'off-duty';
  current_task?: string;
  task_priority?: 'low' | 'medium' | 'high' | 'critical';
  workload_percentage: number;
  location_zone?: string;
  created_at: string;
  updated_at: string;
}

export interface ZoneHistory {
  id: string;
  zone_id: string;
  event_id: string;
  occupancy_snapshot: number;
  density_level: DensityLevel;
  avg_facility_wait: number;
  entry_rate: number;
  exit_rate: number;
  snapshot_time: string;
  created_at: string;
}

export interface FacilityPerformance {
  id: string;
  facility_id: string;
  event_id: string;
  customers_served: number;
  peak_wait_time?: number;
  average_wait_time?: number;
  efficiency_score: number;
  staff_utilization: number;
  peak_time?: string;
  created_at: string;
  updated_at: string;
}

export interface EventTimeline {
  id: string;
  event_id: string;
  event_type: 'kickoff' | 'quarter_change' | 'halftime' | 'timeout' | 'score' | 'substitution' | 'injury' | 'weather_change';
  event_time: string;
  description?: string;
  related_team?: string;
  created_at: string;
}

export type TabId = 'dashboard' | 'map' | 'waittimes' | 'announcements' | 'admin' | 'insights' | 'staff';
