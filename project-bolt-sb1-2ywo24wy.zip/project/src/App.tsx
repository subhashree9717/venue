import { useState } from 'react';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { Dashboard } from './components/Dashboard';
import { InsightsDashboard } from './components/InsightsDashboard';
import { VenueMap } from './components/VenueMap';
import { WaitTimes } from './components/WaitTimes';
import { StaffCoordination } from './components/StaffCoordination';
import { Announcements } from './components/Announcements';
import { AdminPanel } from './components/AdminPanel';
import { LoginPage } from './pages/LoginPage';
import { useVenueData } from './hooks/useVenueData';
import { useAuth } from './contexts/AuthContext';
import type { TabId } from './types';
import { AlertTriangle, RefreshCw } from 'lucide-react';

function LoadingScreen() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center gap-4">
      <div className="w-12 h-12 rounded-2xl bg-blue-500 flex items-center justify-center animate-pulse">
        <span className="text-white text-xl font-black">V</span>
      </div>
      <div className="space-y-2 text-center">
        <p className="font-semibold text-slate-800">Loading VenueIQ</p>
        <p className="text-sm text-slate-400">Connecting to live data...</p>
      </div>
      <div className="flex gap-1.5 mt-2">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="w-2 h-2 rounded-full bg-blue-400 animate-bounce"
            style={{ animationDelay: `${i * 0.15}s` }}
          />
        ))}
      </div>
    </div>
  );
}

function ErrorScreen({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center gap-4 p-6 text-center">
      <div className="w-12 h-12 rounded-2xl bg-red-100 flex items-center justify-center">
        <AlertTriangle size={24} className="text-red-500" />
      </div>
      <div>
        <p className="font-semibold text-slate-800">Connection Error</p>
        <p className="text-sm text-slate-400 mt-1">{message}</p>
      </div>
      <button
        onClick={onRetry}
        className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl font-medium text-sm hover:bg-blue-700 transition-colors"
      >
        <RefreshCw size={16} />
        Retry
      </button>
    </div>
  );
}

export default function App() {
  const { user, loading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<TabId>('dashboard');
  const {
    event, zones, facilities, announcements, predictions, anomalies, staff, zoneHistory, facilityPerformance,
    loading, error,
    updateZoneDensity, updateFacilityWait, addAnnouncement, dismissAnnouncement,
    refetch,
  } = useVenueData();

  if (authLoading) return <LoadingScreen />;
  if (!user) return <LoginPage onSuccess={() => {}} />;

  if (loading) return <LoadingScreen />;
  if (error) return <ErrorScreen message={error} onRetry={refetch} />;

  const criticalAnnouncements = announcements.filter((a) => a.priority === 'critical');

  const PAGE_TITLES: Record<TabId, string> = {
    dashboard: 'Overview',
    insights: 'Predictive Analytics',
    map: 'Venue Map',
    waittimes: 'Wait Times',
    staff: 'Staff Coordination',
    announcements: 'Live Updates',
    admin: 'Operations',
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Header event={event} connected={true} />

      <div className="bg-white border-b border-slate-100 sticky top-[60px] z-30">
        <Navigation
          activeTab={activeTab}
          onTabChange={setActiveTab}
          criticalCount={criticalAnnouncements.length}
        />
      </div>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-5 pb-24 md:pb-8">
        <div className="mb-4">
          <h1 className="text-xl font-bold text-slate-900">{PAGE_TITLES[activeTab]}</h1>
          {event && (
            <p className="text-sm text-slate-400 mt-0.5">
              {event.venue_name} · {event.attendance.toLocaleString()} attending
            </p>
          )}
        </div>

        {activeTab === 'dashboard' && (
          <Dashboard
            event={event}
            zones={zones}
            facilities={facilities}
            announcements={announcements}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'insights' && (
          <InsightsDashboard
            anomalies={anomalies}
            predictions={predictions}
            zoneHistory={zoneHistory}
            zones={zones}
            facilityPerformance={facilityPerformance}
          />
        )}

        {activeTab === 'map' && (
          <VenueMap zones={zones} facilities={facilities} />
        )}

        {activeTab === 'waittimes' && (
          <WaitTimes facilities={facilities} zones={zones} />
        )}

        {activeTab === 'staff' && (
          <StaffCoordination staff={staff} zones={zones} />
        )}

        {activeTab === 'announcements' && (
          <Announcements
            announcements={announcements}
            onDismiss={dismissAnnouncement}
          />
        )}

        {activeTab === 'admin' && (
          <AdminPanel
            event={event}
            zones={zones}
            facilities={facilities}
            onUpdateZone={updateZoneDensity}
            onUpdateFacility={updateFacilityWait}
            onAddAnnouncement={addAnnouncement}
          />
        )}
      </main>
    </div>
  );
}
