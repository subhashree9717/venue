import type { Zone, Facility, CrowdPrediction, CrowdAnomaly, ZoneHistory } from '../types';

export function predictNextSurge(history: ZoneHistory[]): { zone: Zone; riskScore: number; timeToSurge: string }[] {
  if (history.length < 2) return [];

  const grouped = history.reduce((acc, h) => {
    if (!acc[h.zone_id]) acc[h.zone_id] = [];
    acc[h.zone_id].push(h);
    return acc;
  }, {} as Record<string, ZoneHistory[]>);

  const predictions = Object.entries(grouped).map(([zoneId, snapshots]) => {
    const sorted = snapshots.sort((a, b) => new Date(b.snapshot_time).getTime() - new Date(a.snapshot_time).getTime());
    const latest = sorted[0];
    const previous = sorted[1];

    if (!previous || !latest) return null;

    const occupancyChange = latest.occupancy_snapshot - previous.occupancy_snapshot;
    const timeGap = (new Date(latest.snapshot_time).getTime() - new Date(previous.snapshot_time).getTime()) / (1000 * 60);
    const occupancyRate = occupancyChange / timeGap;
    const riskScore = Math.min(100, Math.max(0, latest.occupancy_snapshot * 1.5 + occupancyRate * 50));

    let timeToSurge = '30+ min';
    if (riskScore > 80) timeToSurge = '5-10 min';
    else if (riskScore > 60) timeToSurge = '10-20 min';
    else if (riskScore > 40) timeToSurge = '20-30 min';

    return { zoneId, riskScore, timeToSurge, latest };
  }).filter(Boolean) as any[];

  return predictions;
}

export function calculateFacilityEfficiency(facility: Facility, peakWait: number, avgWait: number): number {
  if (facility.status === 'closed') return 0;
  if (facility.status === 'maintenance') return 25;

  const waitPenalty = Math.max(0, 100 - (avgWait * 5));
  const statusBonus = facility.status === 'open' && avgWait < 5 ? 10 : 0;
  const efficiency = Math.round(Math.max(0, waitPenalty + statusBonus));

  return Math.min(100, efficiency);
}

export function recommendBestFacility(
  facilities: Facility[],
  type: 'concession' | 'restroom',
): Facility | null {
  const filtered = facilities
    .filter((f) => f.facility_type === type && f.status !== 'closed')
    .sort((a, b) => a.current_wait_minutes - b.current_wait_minutes);

  return filtered[0] || null;
}

export function calculateZoneFitnessScore(
  zone: Zone,
  userPreferences?: { avoid_crowds?: boolean },
): number {
  const occupancyPct = zone.current_occupancy / zone.capacity;
  let score = 100 - occupancyPct * 100;

  if (userPreferences?.avoid_crowds) {
    if (zone.density_level === 'critical') score *= 0.1;
    else if (zone.density_level === 'high') score *= 0.3;
    else if (zone.density_level === 'medium') score *= 0.6;
  }

  return Math.round(Math.max(0, score));
}

export function smartRoute(
  fromZone: Zone,
  toZone: Zone,
  allZones: Zone[],
): string {
  const densityOrder = { low: 0, medium: 1, high: 2, critical: 3 };
  const fromDensity = densityOrder[fromZone.density_level];
  const toDensity = densityOrder[toZone.density_level];

  if (fromDensity === 3) {
    return 'URGENT: Exit via least crowded zone. Consider alternate routes.';
  }
  if (toDensity === 3) {
    return `⚠️ ${toZone.name} is at critical capacity. Consider nearby alternatives.`;
  }
  if (toDensity > fromDensity) {
    return `Moving to higher congestion zone. Estimated wait time increase.`;
  }

  return `Clear path to ${toZone.name}. Lower congestion expected.`;
}

export function generateTrendArrow(current: number, previous: number): string {
  if (current > previous * 1.05) return '📈 Increasing';
  if (current < previous * 0.95) return '📉 Decreasing';
  return '→ Stable';
}
