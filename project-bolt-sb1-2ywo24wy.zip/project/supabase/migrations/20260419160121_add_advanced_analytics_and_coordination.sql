/*
  # Advanced Analytics and Coordination Schema

  ## New Tables for Enhanced Features

  ### 1. crowd_predictions
  - ML-powered crowd density forecasts for each zone
  - 15-min, 1-hour, and 4-hour predictions
  - Confidence scores and trending data

  ### 2. user_preferences
  - Stores attendee preferences (anonymous or auth-based)
  - Favorite vendors, accessibility needs, family-friendly filters
  - Personalization for routing recommendations

  ### 3. staff_assignments
  - Real-time staff location and task assignments
  - Zone assignments with status tracking (break, assigned, en-route, on-scene)
  - Workload balancing

  ### 4. crowd_anomalies
  - Detected surge events, bottlenecks, and unusual patterns
  - Severity levels (minor, moderate, severe, critical)
  - Auto-triggered mitigation recommendations

  ### 5. facility_performance
  - Historical metrics: throughput, peak times, efficiency
  - Staff capacity vs demand analysis
  - Performance alerts when efficiency drops

  ### 6. event_timeline
  - Structured event moments: kickoff, quarter changes, halftime, timeouts
  - Used to correlate crowd movements with game events
  - Enables predictive alerts before surge events

  ### 7. zone_history
  - Time-series data for crowd density and facility performance
  - 15-min aggregated snapshots for analytics
  - Historical heatmap generation

  ## Security
  - RLS on all new tables with authenticated user checks
  - Staff tables restricted to authenticated roles
  - Prediction data is public (read-only for attendees)
*/

-- Crowd predictions table
CREATE TABLE IF NOT EXISTS crowd_predictions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  zone_id uuid NOT NULL REFERENCES zones(id) ON DELETE CASCADE,
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  predicted_occupancy integer NOT NULL,
  confidence_score numeric NOT NULL CHECK (confidence_score >= 0 AND confidence_score <= 100),
  time_horizon text NOT NULL CHECK (time_horizon IN ('15min', '1hour', '4hour')),
  trend_direction text NOT NULL CHECK (trend_direction IN ('increasing', 'stable', 'decreasing')),
  predicted_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE crowd_predictions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read predictions"
  ON crowd_predictions FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert predictions"
  ON crowd_predictions FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- User preferences for personalization
CREATE TABLE IF NOT EXISTS user_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_identifier text NOT NULL,
  favorite_facilities text[] DEFAULT '{}',
  accessibility_needs text[] DEFAULT '{}',
  family_friendly boolean DEFAULT false,
  avoid_crowds boolean DEFAULT false,
  preferred_areas text[] DEFAULT '{}',
  dietary_restrictions text[] DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(event_id, user_identifier)
);

ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own preferences"
  ON user_preferences FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own preferences"
  ON user_preferences FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Staff assignments and coordination
CREATE TABLE IF NOT EXISTS staff_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  zone_id uuid REFERENCES zones(id) ON DELETE SET NULL,
  staff_name text NOT NULL,
  role text NOT NULL CHECK (role IN ('crowd_control', 'medical', 'vendor_support', 'security', 'maintenance', 'guest_services')),
  status text NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'break', 'assigned', 'en-route', 'on-scene', 'off-duty')),
  current_task text,
  task_priority text CHECK (task_priority IN ('low', 'medium', 'high', 'critical')),
  workload_percentage integer DEFAULT 0,
  location_zone uuid REFERENCES zones(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE staff_assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated staff can read assignments"
  ON staff_assignments FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated staff can update assignments"
  ON staff_assignments FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Crowd anomalies and surge detection
CREATE TABLE IF NOT EXISTS crowd_anomalies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  zone_id uuid NOT NULL REFERENCES zones(id) ON DELETE CASCADE,
  anomaly_type text NOT NULL CHECK (anomaly_type IN ('surge', 'bottleneck', 'evacuation', 'unusual_pattern', 'congestion_peak')),
  severity text NOT NULL DEFAULT 'moderate' CHECK (severity IN ('minor', 'moderate', 'severe', 'critical')),
  description text NOT NULL,
  predicted_peak_occupancy integer,
  mitigation_suggested text,
  resolved boolean DEFAULT false,
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE crowd_anomalies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read anomalies"
  ON crowd_anomalies FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert anomalies"
  ON crowd_anomalies FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update anomalies"
  ON crowd_anomalies FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Facility performance metrics
CREATE TABLE IF NOT EXISTS facility_performance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  facility_id uuid NOT NULL REFERENCES facilities(id) ON DELETE CASCADE,
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  customers_served integer DEFAULT 0,
  peak_wait_time integer,
  average_wait_time integer,
  efficiency_score numeric DEFAULT 75,
  staff_utilization numeric DEFAULT 50,
  peak_time text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE facility_performance ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read performance data"
  ON facility_performance FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert performance data"
  ON facility_performance FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Event timeline for context
CREATE TABLE IF NOT EXISTS event_timeline (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  event_type text NOT NULL CHECK (event_type IN ('kickoff', 'quarter_change', 'halftime', 'timeout', 'score', 'substitution', 'injury', 'weather_change')),
  event_time timestamptz NOT NULL,
  description text,
  related_team text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE event_timeline ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read timeline"
  ON event_timeline FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert timeline events"
  ON event_timeline FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Zone history for time-series analytics
CREATE TABLE IF NOT EXISTS zone_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  zone_id uuid NOT NULL REFERENCES zones(id) ON DELETE CASCADE,
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  occupancy_snapshot integer NOT NULL,
  density_level text NOT NULL,
  avg_facility_wait integer DEFAULT 0,
  entry_rate integer DEFAULT 0,
  exit_rate integer DEFAULT 0,
  snapshot_time timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE zone_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read zone history"
  ON zone_history FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert history"
  ON zone_history FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_crowd_predictions_zone_time ON crowd_predictions(zone_id, predicted_at DESC);
CREATE INDEX IF NOT EXISTS idx_crowd_anomalies_event_zone ON crowd_anomalies(event_id, zone_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_facility_performance_facility ON facility_performance(facility_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_zone_history_zone_time ON zone_history(zone_id, snapshot_time DESC);
CREATE INDEX IF NOT EXISTS idx_event_timeline_event_time ON event_timeline(event_id, event_time DESC);
CREATE INDEX IF NOT EXISTS idx_staff_assignments_zone_status ON staff_assignments(zone_id, status);
