/*
  # Venue Experience Platform Schema

  ## Overview
  This migration creates the full schema for a large-scale sporting venue management system
  that tracks crowd density, facility wait times, announcements, and staff coordination.

  ## New Tables

  ### 1. events
  - Stores active sporting events at the venue
  - Tracks event metadata: sport type, team names, start time, status

  ### 2. zones
  - Represents named sections/areas within the venue (e.g., North Stand, VIP Level)
  - Tracks real-time occupancy and computed density level (low/medium/high/critical)
  - Each zone has a capacity and current_occupancy for live crowd density

  ### 3. facilities
  - Individual facilities within each zone (concessions, restrooms, first aid, exits, gates)
  - Stores current wait time in minutes and operational status
  - Linked to a zone for location context

  ### 4. announcements
  - Broadcast messages for attendees and staff
  - Priority levels: info, warning, critical
  - Optional expiry timestamp so stale messages auto-hide

  ### 5. staff_alerts
  - Internal coordination messages sent to specific zones or venue-wide
  - Tracks acknowledged status so dispatchers know alerts are received

  ## Security
  - RLS enabled on all tables
  - Public read access for attendee-facing data (events, zones, facilities, announcements)
  - Authenticated write access for admin operations
*/

-- Events table
CREATE TABLE IF NOT EXISTS events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  venue_name text NOT NULL DEFAULT 'Arena Stadium',
  sport_type text NOT NULL DEFAULT 'football',
  home_team text NOT NULL,
  away_team text NOT NULL,
  home_score integer NOT NULL DEFAULT 0,
  away_score integer NOT NULL DEFAULT 0,
  scheduled_at timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'upcoming' CHECK (status IN ('upcoming', 'pregame', 'live', 'halftime', 'finished')),
  current_period text,
  attendance integer NOT NULL DEFAULT 0,
  capacity integer NOT NULL DEFAULT 65000,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read events"
  ON events FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated users can update events"
  ON events FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Zones table
CREATE TABLE IF NOT EXISTS zones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid REFERENCES events(id) ON DELETE CASCADE,
  name text NOT NULL,
  section_code text NOT NULL,
  capacity integer NOT NULL DEFAULT 5000,
  current_occupancy integer NOT NULL DEFAULT 0,
  density_level text NOT NULL DEFAULT 'low' CHECK (density_level IN ('low', 'medium', 'high', 'critical')),
  x_position numeric NOT NULL DEFAULT 0,
  y_position numeric NOT NULL DEFAULT 0,
  width numeric NOT NULL DEFAULT 100,
  height numeric NOT NULL DEFAULT 80,
  color_override text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE zones ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read zones"
  ON zones FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated users can update zones"
  ON zones FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Facilities table
CREATE TABLE IF NOT EXISTS facilities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  zone_id uuid REFERENCES zones(id) ON DELETE CASCADE,
  facility_type text NOT NULL CHECK (facility_type IN ('concession', 'restroom', 'first_aid', 'exit', 'gate', 'merchandise')),
  name text NOT NULL,
  description text,
  current_wait_minutes integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'busy', 'closed', 'maintenance')),
  staff_count integer NOT NULL DEFAULT 2,
  location_detail text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE facilities ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read facilities"
  ON facilities FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated users can update facilities"
  ON facilities FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Announcements table
CREATE TABLE IF NOT EXISTS announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid REFERENCES events(id) ON DELETE CASCADE,
  title text NOT NULL,
  message text NOT NULL,
  priority text NOT NULL DEFAULT 'info' CHECK (priority IN ('info', 'warning', 'critical')),
  target_zones text[] DEFAULT '{}',
  expires_at timestamptz,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read active announcements"
  ON announcements FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Authenticated users can insert announcements"
  ON announcements FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update announcements"
  ON announcements FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Staff alerts table
CREATE TABLE IF NOT EXISTS staff_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid REFERENCES events(id) ON DELETE CASCADE,
  zone_id uuid REFERENCES zones(id) ON DELETE SET NULL,
  alert_type text NOT NULL CHECK (alert_type IN ('crowd_surge', 'medical', 'security', 'facility', 'general')),
  message text NOT NULL,
  priority text NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'critical')),
  acknowledged boolean NOT NULL DEFAULT false,
  acknowledged_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE staff_alerts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read staff alerts"
  ON staff_alerts FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert staff alerts"
  ON staff_alerts FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update staff alerts"
  ON staff_alerts FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);
